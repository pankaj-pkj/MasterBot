# SPIX1 — Termux Edition

A personal, on-device assistant for Android: chat (CLI + web dashboard),
voice, device control (calls/SMS/apps/media), file management, system
info, and an optional local-or-cloud reasoning backend. Runs entirely
under Termux — no root required.

## What this actually is

SPIX1's "brain" (`core/`) is a **rule-based** engine: regex intent
matching + a persistent store of facts and Q→A pairs it accumulates
from your conversations (`core/self_learning.py`), with a fuzzy-match
recall step. That's genuinely useful — it gets more tailored to you
over time, remembers what you teach it, and answers instantly with no
internet — but it's a different kind of system from a neural-network
model like Claude, GPT, or similar, and no phone can locally run
something with that level of general reasoning. Calling it "advanced
self-learning" in the original banner oversold that a little; this
README describes what it actually does.

To get closer to that kind of reasoning when you want it, `core/api_manager.py`
adds an **optional** fallback the rule-based matcher can defer to: either
a small model you run yourself on-device via llama.cpp, or your own
Claude/OpenAI-compatible API key. Both are off by default — SPIX1 runs
fully offline with zero setup either way.

## What was in the uploaded zip vs. what's here now

The archive only contained `core/` + `main.py` + `config.py` — it
imported from `voice/`, `system/`, and `web/` packages that didn't
exist anywhere in it, so `python main.py` would fail immediately with
`ModuleNotFoundError`. Those packages are now written, targeting
Termux/Android instead of the original desktop assumptions
(`pyttsx3`/`pyaudio` for voice, `pywhatkit` browser automation for
messaging — neither works on Android):

- **`voice/`** — TTS/STT via `termux-tts-speak` / `termux-speech-to-text`
  (Android's own on-device engine, not pyttsx3/PortAudio)
- **`system/kernel_control.py`** — status, processes, network info,
  and shell execution (off by default — see Security below)
- **`system/alarm_manager.py`** — real alarms via Android's Clock app
  intent, not a background Python timer (which Android would kill)
- **`system/file_manager.py`** — create/read/delete under your shared
  storage, with soft-delete to a trash folder
- **`system/app_manager.py`** — opens installed apps by name
- **`system/messaging.py`** — SMS and calls via Termux:API
- **`system/knowledge_source.py`** — Wikipedia + DuckDuckGo lookups,
  no API key
- **`web/server.py`** — the dashboard, rewritten to bind to localhost
  only and use a per-install random secret key instead of one hardcoded
  in source
- **`core/api_manager.py`** — the optional local/cloud reasoning
  backend described above

`core/ai_engine.py`, `nlp_processor.py`, `self_learning.py`,
`human_behavior.py`, `memory.py`, and `command_router.py` were kept as
they were designed — they're portable pure Python — except for two bug
fixes in `nlp_processor.py` found by testing: "network status" was
always being read as "system status" (both matched on the shared word
"status"), and "read file.txt"/"delete file.txt" without the literal
word "file" fell through to the wrong handler. Both are fixed.

## Quick start

```
unzip SPIX1.zip && cd SPIX1
bash setup_termux.sh
python main.py
```

Dashboard at `http://127.0.0.1:5050` in the phone's own browser. See
`setup_termux.sh`'s output for the Termux:API app requirement (a
separate install from the `termux-api` package) and the optional
local-model steps.

## Security changes from the original

The original had the dashboard on `0.0.0.0` (reachable by anything on
the same Wi-Fi) with a secret key hardcoded in source, and shell
command execution wired up and always on. On a phone — which joins
public/shared networks far more than a desktop does — that combination
is a real exposure. Now:

- Dashboard defaults to `127.0.0.1` (change deliberately in `config.py`
  if you actually want LAN access)
- Secret key is generated per-install, not shipped in source
- Shell access is **off by default**; turn it on in the dashboard's
  Settings tab if you want it. Every command run this way is logged to
  `data/shell_audit.log`

## What's intentionally not included

No autonomous "penetration testing" or exploitation capability was
built in — nothing that scans, probes, or attacks other systems on its
own initiative. That's a different kind of tool than a personal device
assistant, and not something to wire into a general "do anything"
agent regardless of the intent behind it.

Standard security/network tools (`nmap`, `tcpdump`, etc.) are just a
`pkg install` away in Termux, same as they always were — SPIX1's shell
access (once you enable it) can run them like anything else. Driving
those deliberately yourself, against systems you're authorized to test,
is a different and much safer posture than an agent that decides on
its own to go probe something. If you want a specific scoped tool built
later — e.g. a script that runs nmap and formats the findings into a
report — that's a much more targeted, reasonable ask than a
general-purpose autonomous capability, happy to help with that kind of
thing directly.

## Real limitations worth knowing

- **Process visibility**: on a non-rooted phone, Android generally
  only lets Termux see its own process tree, not a full system-wide
  list the way a desktop would. `list processes` will be a lot shorter
  on your phone than it might look in testing.
- **Closing other apps**: Android reserves force-stop for the system
  itself. `close_app` is attempted but will usually fail on a
  non-rooted device — that's a platform limit, not a bug.
- **Alarm list**: alarms are handed off to Android's real Clock app
  (so they're reliable even if Termux is killed), but Android doesn't
  expose a way to read that list back. `list alarms` shows what SPIX1
  itself has set recently, not the phone's full current alarm state.
- **WhatsApp/Telegram messaging**: not reachable this way — that needs
  either an official Business API or accessibility-service automation
  (a bigger, separate project). Plain SMS and calls work directly.

## Extending it

Everything routes through `core/command_router.py`'s `HANDLERS` dict —
add an intent pattern in `nlp_processor.py` and a handler method to add
a new capability.
