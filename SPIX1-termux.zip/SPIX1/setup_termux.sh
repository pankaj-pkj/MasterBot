#!/data/data/com.termux/files/usr/bin/bash
# SPIX1 — Termux setup
# Run this from inside Termux, on the phone, with internet on:
#   bash setup_termux.sh

set -e
echo "== SPIX1 Termux setup =="

echo "-- Updating packages --"
pkg update -y && pkg upgrade -y

echo "-- Installing base packages --"
# python-numpy/python-cryptography as native binaries where possible,
# to avoid slow from-source pip builds on-device.
pkg install -y python python-pip git clang termux-api

echo "-- Requesting shared storage access --"
echo "   (a permission prompt will appear on screen)"
termux-setup-storage
sleep 2

echo "-- Installing Python dependencies --"
pip install -r requirements.txt || pip install --break-system-packages -r requirements.txt

cat <<'EOF'

== Termux:API — important ==
The `pkg install termux-api` above only installs the command-line
bridge. You ALSO need the separate "Termux:API" app installed for
calls/SMS/TTS/STT/battery/etc to work.

Termux and Termux:API must come from the SAME source or the bridge
silently fails:
  - Both from F-Droid  (recommended, actively maintained), or
  - Both from the Termux GitHub releases page
Do not mix a Play Store Termux with an F-Droid Termux:API (or vice
versa) — the Play Store build of Termux is outdated and this
combination is a common cause of "it does nothing" reports.

After installing the app, open it once, then in Termux grant whatever
permissions Android prompts for (SMS, phone, microphone, contacts) the
first time you use each feature.

== Optional: local on-device model (no API key, no internet) ==
SPIX1 runs fully offline with its built-in rule-based engine by
default — this step is only if you also want a real local LLM as a
fallback for open-ended questions.

  pkg install cmake
  git clone https://github.com/ggerganov/llama.cpp
  cd llama.cpp && cmake -B build && cmake --build build --config Release -j
  cd ..

Then download a small GGUF-quantized instruct model (1–3B parameters
fits comfortably on most phones — search Hugging Face for e.g.
"Qwen2.5-1.5B-Instruct-GGUF" or "Llama-3.2-3B-Instruct-GGUF", pick a
Q4_K_M file, and note the exact current filename before downloading —
model listings change, so check Hugging Face directly rather than
trusting an old link) into llama.cpp/models/, then run:

  ./llama.cpp/build/bin/llama-server -m llama.cpp/models/<your-model>.gguf --port 8080

With that running in a second Termux session, open the SPIX1 dashboard
-> Settings -> set Reasoning backend to "Local model", Base URL
http://127.0.0.1:8080, and save.

== Start SPIX1 ==
  python main.py

Dashboard: http://127.0.0.1:5050 (open in the phone's own browser)
Type 'talk' in the CLI for one voice exchange, or 'exit' to quit.
EOF
