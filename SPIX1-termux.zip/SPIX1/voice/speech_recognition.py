"""
SPIX1 — Speech Recognition
Wraps `termux-speech-to-text`, which uses Android's own on-device
speech recognizer — no pyaudio/PortAudio build headaches on Android.
Requires the Termux:API app installed and microphone permission granted.
"""

import shutil
import subprocess


class STTEngine:

    def __init__(self):
        if not shutil.which("termux-speech-to-text"):
            raise RuntimeError(
                "termux-speech-to-text not found — install the Termux:API app "
                "and run: pkg install termux-api"
            )

    def listen(self):
        try:
            result = subprocess.run(["termux-speech-to-text"], capture_output=True,
                                     text=True, timeout=20)
            heard = result.stdout.strip()
            return heard or None
        except Exception:
            return None
