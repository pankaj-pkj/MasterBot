"""
SPIX1 — Speech Synthesis
Wraps `termux-tts-speak`, which hands text to Android's own on-device
TTS engine — fully offline, no desktop-style pyttsx3/PortAudio needed.
Requires the Termux:API app installed.
"""

import shutil
import subprocess


class TTSEngine:

    def __init__(self):
        if not shutil.which("termux-tts-speak"):
            raise RuntimeError(
                "termux-tts-speak not found — install the Termux:API app "
                "and run: pkg install termux-api"
            )

    def speak(self, text):
        if not text:
            return
        try:
            subprocess.run(["termux-tts-speak", text], timeout=30)
        except Exception:
            # Voice is best-effort — never let a TTS failure break the chat flow.
            pass
