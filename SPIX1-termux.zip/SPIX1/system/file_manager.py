"""
SPIX1 — File Manager
Create / read / delete files, scoped to FILES_BASE_DIR (your shared
Android storage once you've run `termux-setup-storage`, otherwise a
local folder inside the project).

Two safety choices, since these actions are triggered by loosely-parsed
natural language rather than exact commands:
  - every path is resolved and checked to stay inside FILES_BASE_DIR
    (no "../../" escaping it)
  - "delete" is a soft delete — files move to a .spix1_trash folder
    instead of being unlinked immediately, so a misheard request
    doesn't cost you data
"""

import os
import re
import shutil
from datetime import datetime

from config import FILES_BASE_DIR


class FileManager:

    def __init__(self):
        os.makedirs(FILES_BASE_DIR, exist_ok=True)
        self.trash_dir = os.path.join(FILES_BASE_DIR, ".spix1_trash")

    # ─── Public handlers (match command_router's calling convention) ──
    def create(self, entities, raw):
        name, content = self._parse_name_and_content(entities, raw)
        if not name:
            return "What should I name the file?"
        path = self._safe_path(name)
        if path is None:
            return "That file name isn't valid — try something simpler, without '..' or a leading '/'."
        if os.path.exists(path):
            return f"'{os.path.basename(path)}' already exists there. Ask me to read it, or pick a different name."
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                f.write(content)
            where = os.path.relpath(path, FILES_BASE_DIR)
            if content:
                return f"Created '{where}' with the content you gave me."
            return (f"Created '{where}'. Tell me to write something to it "
                    f"if you want content in it.")
        except Exception as e:
            return f"Couldn't create that file: {e}"

    def read(self, entities, raw):
        name = self._pick_name(entities, raw)
        if not name:
            return "Which file should I read?"
        path = self._safe_path(name)
        if path is None or not os.path.isfile(path):
            match = self._fuzzy_find(name)
            if match:
                path = match
            else:
                return f"I can't find a file called '{name}' in your SPIX1 storage folder."
        try:
            size = os.path.getsize(path)
            if size > 50_000:
                return f"That file is {size // 1024}KB — too large to read out here. Open it with a file app instead."
            with open(path, "r", errors="replace") as f:
                data = f.read()
            return data if data.strip() else "(that file is empty)"
        except Exception as e:
            return f"Couldn't read that file: {e}"

    def delete(self, entities, raw):
        name = self._pick_name(entities, raw)
        if not name:
            return "Which file should I delete?"
        path = self._safe_path(name)
        if path is None or not os.path.isfile(path):
            match = self._fuzzy_find(name)
            if not match:
                return f"I can't find a file called '{name}' to delete."
            path = match
        try:
            os.makedirs(self.trash_dir, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join(self.trash_dir, f"{stamp}_{os.path.basename(path)}")
            shutil.move(path, dest)
            return (f"Moved '{os.path.basename(path)}' to .spix1_trash instead of "
                    f"deleting it outright — say the word if you want it back, "
                    f"or clear that folder yourself when you're sure.")
        except Exception as e:
            return f"Couldn't delete that file: {e}"

    # ─── Helpers ────────────────────────────────────────────────
    def _parse_name_and_content(self, entities, raw):
        # Pull out "with/containing/saying '...'" as content FIRST, then hunt
        # for the filename in what's left — a lone quoted string in a
        # request like this is content, not the name.
        content = ""
        remainder = raw
        m = re.search(r'(?:with|containing|saying)\s+["\'](.+?)["\']', raw, re.IGNORECASE)
        if m:
            content = m.group(1)
            remainder = raw[:m.start()] + raw[m.end():]

        name = self._pick_name(entities, remainder)
        return name, content

    def _pick_name(self, entities, raw):
        # Prefer an explicit quoted name.
        quotes = re.findall(r'["\']([^"\']+)["\']', raw)
        if quotes:
            return quotes[0].strip()
        # Then a bare "word.ext" token — a strong, unambiguous filename signal.
        m = re.search(r'\b([\w\-]+\.\w{1,5})\b', raw)
        if m:
            return m.group(1)
        # Last resort: whatever nlp_processor guessed.
        return (entities.get("filename") or "").strip()

    def _safe_path(self, name):
        if not name or ".." in name or name.startswith("/") or name.startswith("~"):
            return None
        path = os.path.realpath(os.path.join(FILES_BASE_DIR, name))
        base = os.path.realpath(FILES_BASE_DIR)
        if os.path.commonpath([path, base]) != base:
            return None
        return path

    def _fuzzy_find(self, name):
        """Best-effort: find a file in FILES_BASE_DIR whose name contains the query."""
        target = name.lower()
        for root, _, files in os.walk(FILES_BASE_DIR):
            if ".spix1_trash" in root:
                continue
            for f in files:
                if target in f.lower():
                    return os.path.join(root, f)
        return None
