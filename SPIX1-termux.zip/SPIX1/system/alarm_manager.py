"""
SPIX1 — Alarm Manager
Sets real alarms through Android's own Clock app via the SET_ALARM
intent, rather than timing things in a background Python thread.

That choice is deliberate: Android suspends/kills backgrounded Termux
processes (battery optimization, or just closing the terminal), so a
Python-side timer can silently fail to ever go off. A system alarm
created this way survives all of that, the same as one you'd set by
hand in the Clock app.

Trade-off: Android doesn't expose a way to read back the Clock app's
current alarm list, so `list_alarms()` shows what *SPIX1* has set
recently (from its own local log) — not necessarily every alarm on the
phone, since you can also add/remove alarms directly in Clock.
"""

import os
import re
import json
import shutil
import subprocess
from datetime import datetime, timedelta

from config import ALARM_LOG_FILE, DATA_DIR


class AlarmManager:

    def __init__(self, engine=None):
        self.engine = engine
        os.makedirs(DATA_DIR, exist_ok=True)

    def start(self):
        # No background loop needed — see module docstring. Just make
        # sure the local log exists so list_alarms() has something to read.
        if not os.path.exists(ALARM_LOG_FILE):
            self._save([])

    def stop(self):
        pass

    def set_alarm_from_command(self, raw, entities):
        when = self._resolve_time(entities)
        if when is None:
            return ("I couldn't work out a time from that. Try something "
                     "like 'set an alarm for 7:30am' or 'remind me in 20 minutes'.")

        label = self._label_from_raw(raw)
        if not shutil.which("am"):
            return "Setting alarms needs Android's `am` tool, which wasn't found here."

        try:
            subprocess.run([
                "am", "start", "-a", "android.intent.action.SET_ALARM",
                "-e", "android.intent.extra.alarm.HOUR", str(when.hour),
                "-e", "android.intent.extra.alarm.MINUTES", str(when.minute),
                "-e", "android.intent.extra.alarm.MESSAGE", label,
                "-e", "android.intent.extra.alarm.SKIP_UI", "true",
            ], capture_output=True, text=True, timeout=10)
        except Exception as e:
            return f"Couldn't set that alarm: {e}"

        self._log_alarm(label, when)
        return f"Alarm set for {when.strftime('%I:%M %p').lstrip('0')} — \"{label}\"."

    def list_alarms(self):
        alarms = self._load()
        upcoming = [a for a in alarms if a.get("time", "") >= datetime.now().isoformat()]
        return [{"label": a["label"], "time": self._pretty(a["time"])} for a in upcoming[-20:]]

    # ─── Time parsing ───────────────────────────────────────────
    def _resolve_time(self, entities):
        now = datetime.now()

        duration = entities.get("duration")
        if duration:
            m = re.search(r"(\d+)\s*(minute|min|hour|hr)", duration, re.IGNORECASE)
            if m:
                n = int(m.group(1))
                unit = m.group(2).lower()
                delta = timedelta(hours=n) if unit.startswith("h") else timedelta(minutes=n)
                return now + delta

        time_str = entities.get("time")
        if time_str:
            m = re.match(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", time_str.strip(), re.IGNORECASE)
            if m:
                hour = int(m.group(1))
                minute = int(m.group(2) or 0)
                ampm = (m.group(3) or "").lower()
                if ampm == "pm" and hour != 12:
                    hour += 12
                elif ampm == "am" and hour == 12:
                    hour = 0
                target = now.replace(hour=hour % 24, minute=minute, second=0, microsecond=0)
                if target <= now and not ampm:
                    # Ambiguous 24h-style hour already passed today — assume tomorrow.
                    target += timedelta(days=1)
                elif target <= now and ampm:
                    target += timedelta(days=1)
                return target

        return None

    def _label_from_raw(self, raw):
        m = re.search(r"(?:remind me to|reminder to)\s+(.+)", raw, re.IGNORECASE)
        if m:
            return m.group(1).strip()[:80]
        return "SPIX1 alarm"

    # ─── Local log (for list_alarms only — see docstring) ───────
    def _load(self):
        try:
            with open(ALARM_LOG_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return []

    def _save(self, alarms):
        try:
            with open(ALARM_LOG_FILE, "w") as f:
                json.dump(alarms[-100:], f, indent=2)
        except Exception:
            pass

    def _log_alarm(self, label, when):
        alarms = self._load()
        alarms.append({"label": label, "time": when.isoformat()})
        self._save(alarms)

    def _pretty(self, iso_time):
        try:
            return datetime.fromisoformat(iso_time).strftime("%a %I:%M %p").lstrip("0")
        except Exception:
            return iso_time
