"""
SPIX1 — Messaging Manager
Real SMS and phone calls via Termux:API (termux-sms-send,
termux-telephony-call), plus a best-effort contact-name lookup via
termux-contact-list.

Needs the Termux:API app installed and its SMS/Phone/Contacts
permissions granted on first use — Android will prompt for these.

Note on WhatsApp/Telegram/etc: those aren't reachable this way. Sending
through them needs either an official Business API or an Android
accessibility-service automation app (like Tasker) — a different,
bigger project than a Termux CLI script. Plain SMS and calls are the
reliable route here.
"""

import json
import re
import shutil
import subprocess


class MessagingManager:

    def send(self, entities, raw):
        number = self._resolve_number(entities.get("recipient"))
        if not number:
            return "Who should I text, and what number or saved contact?"
        message = entities.get("message") or self._quoted_fallback(raw)
        if not message:
            return "What should the message say? Try: send message to <number> \"your text\""
        if not shutil.which("termux-sms-send"):
            return "SMS needs the Termux:API app installed (pkg install termux-api, plus the Termux:API app itself)."
        try:
            result = subprocess.run(
                ["termux-sms-send", "-n", number, message],
                capture_output=True, text=True, timeout=15,
            )
            if result.returncode == 0:
                return f"Sent to {number}."
            return f"SMS didn't go through: {result.stderr.strip() or 'unknown error'}"
        except Exception as e:
            return f"Couldn't send that text: {e}"

    def call(self, entities, raw):
        number = self._resolve_number(entities.get("recipient"))
        if not number:
            return "Who should I call?"
        if not shutil.which("termux-telephony-call"):
            return "Calling needs the Termux:API app installed (pkg install termux-api, plus the Termux:API app itself)."
        try:
            result = subprocess.run(["termux-telephony-call", number],
                                     capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                return f"Calling {number}."
            return f"Couldn't place the call: {result.stderr.strip() or 'unknown error'}"
        except Exception as e:
            return f"Couldn't place that call: {e}"

    # ─── Helpers ────────────────────────────────────────────────
    def _resolve_number(self, recipient):
        if not recipient:
            return None
        recipient = recipient.strip()
        digits = re.sub(r"[^\d+]", "", recipient)
        if len(digits) >= 7:
            return digits
        return self._lookup_contact(recipient)

    def _lookup_contact(self, name):
        if not shutil.which("termux-contact-list"):
            return None
        try:
            result = subprocess.run(["termux-contact-list"], capture_output=True,
                                     text=True, timeout=10)
            contacts = json.loads(result.stdout)
            name_lower = name.lower()
            for c in contacts:
                if name_lower in c.get("name", "").lower():
                    numbers = c.get("number")
                    if numbers:
                        return numbers if isinstance(numbers, str) else numbers[0]
        except Exception:
            pass
        return None

    def _quoted_fallback(self, raw):
        m = re.search(r'["\']([^"\']+)["\']', raw)
        return m.group(1) if m else None
