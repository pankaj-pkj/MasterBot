"""
SPIX1 — Knowledge Source
Looks things up on the open internet with no API key required:
Wikipedia first (good for "what is X" / "who is X"), then a DuckDuckGo
instant-answer fallback for broader queries. Needs the phone to have a
data/Wi-Fi connection; if it's offline this just says so.
"""

import requests


class KnowledgeSource:

    def search(self, query):
        query = (query or "").strip()
        if not query:
            return "What would you like me to look up?"

        wiki = self._wikipedia(query)
        if wiki:
            return wiki

        ddg = self._duckduckgo(query)
        if ddg:
            return ddg

        return (f"I couldn't find a clear answer for \"{query}\". "
                f"Your connection might be offline, or it may be too "
                f"specific for a quick lookup.")

    def _wikipedia(self, query):
        try:
            import wikipedia
            try:
                summary = wikipedia.summary(query, sentences=3, auto_suggest=True)
                return summary.strip()
            except wikipedia.exceptions.DisambiguationError as e:
                if e.options:
                    return ("That could mean a few things: "
                            + ", ".join(e.options[:5]) + ". Which did you mean?")
            except wikipedia.exceptions.PageError:
                return None
        except ImportError:
            # wikipedia package not installed — fall through to DuckDuckGo
            pass
        except Exception:
            pass
        return None

    def _duckduckgo(self, query):
        try:
            resp = requests.get(
                "https://api.duckduckgo.com/",
                params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            text = data.get("AbstractText") or data.get("Answer")
            if text:
                return text.strip()
            topics = data.get("RelatedTopics") or []
            for t in topics:
                if isinstance(t, dict) and t.get("Text"):
                    return t["Text"].strip()
        except Exception:
            pass
        return None
