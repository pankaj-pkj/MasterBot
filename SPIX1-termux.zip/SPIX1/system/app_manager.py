"""
SPIX1 — App Manager
Opens installed Android apps by name, using the same `am`/`monkey`/`pm`
utilities Termux already ships with — no root, no extra permissions.

Closing apps is included but limited honestly: Android reserves
`force-stop` for the system/shell UID, which a non-rooted Termux
normally doesn't have. It's attempted, but expect it to only work on
rooted devices — this is a platform limit, not something SPIX1 can
work around.
"""

import shutil
import subprocess

# Common shorthand -> package name, so "open whatsapp" doesn't need an
# exact match against installed packages. Extend this dict freely.
KNOWN_PACKAGES = {
    "whatsapp": "com.whatsapp",
    "youtube": "com.google.android.youtube",
    "chrome": "com.android.chrome",
    "gmail": "com.google.android.gm",
    "camera": "com.android.camera",
    "gallery": "com.google.android.apps.photos",
    "photos": "com.google.android.apps.photos",
    "settings": "com.android.settings",
    "play store": "com.android.vending",
    "maps": "com.google.android.apps.maps",
    "telegram": "org.telegram.messenger",
    "instagram": "com.instagram.android",
    "facebook": "com.facebook.katana",
    "spotify": "com.spotify.music",
    "termux": "com.termux",
    "calculator": "com.android.calculator2",
    "clock": "com.android.deskclock",
    "phone": "com.android.dialer",
    "messages": "com.android.mms",
}


class AppManager:

    def open(self, entities, raw):
        target = (entities.get("target") or "").strip().lower()
        if not target:
            return "Which app should I open?"

        pkg = KNOWN_PACKAGES.get(target) or self._find_installed(target)
        if not pkg:
            return (f"I couldn't find an app matching '{target}' on this "
                     f"device. Check the exact name, or it may need to be "
                     f"added to KNOWN_PACKAGES in system/app_manager.py.")

        if not shutil.which("monkey") and not shutil.which("am"):
            return "Launching apps needs Android's `am`/`monkey` tools, which weren't found on this device."

        try:
            result = subprocess.run(
                ["monkey", "-p", pkg, "-c", "android.intent.category.LAUNCHER", "1"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return f"Opening {target}."
            return f"Tried to open {target}, but the system reported: {result.stderr.strip() or 'unknown error'}"
        except Exception as e:
            return f"Couldn't open {target}: {e}"

    def close(self, entities, raw):
        target = (entities.get("target") or "").strip().lower()
        if not target:
            return "Which app should I close?"

        pkg = KNOWN_PACKAGES.get(target) or self._find_installed(target)
        if not pkg:
            return f"I couldn't find an app matching '{target}' to close."

        try:
            result = subprocess.run(["am", "force-stop", pkg], capture_output=True,
                                     text=True, timeout=10)
            if result.returncode == 0 and not result.stderr.strip():
                return f"Closed {target}."
            return (f"Android didn't let me force-stop {target} — on most "
                     f"non-rooted phones, only the system itself can do that. "
                     f"You'll need to close it from Recents.")
        except Exception as e:
            return f"Couldn't close {target}: {e}"

    def _find_installed(self, query):
        """Fuzzy-match against actually installed packages via `pm list packages`."""
        if not shutil.which("pm"):
            return None
        try:
            result = subprocess.run(["pm", "list", "packages"], capture_output=True,
                                     text=True, timeout=10)
            packages = [line.replace("package:", "").strip()
                        for line in result.stdout.splitlines()]
            query_tokens = query.replace(" ", "")
            for pkg in packages:
                if query_tokens in pkg.lower().replace(".", ""):
                    return pkg
        except Exception:
            pass
        return None
