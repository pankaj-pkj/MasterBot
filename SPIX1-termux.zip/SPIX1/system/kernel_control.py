"""
SPIX1 — Kernel Controller
System status, process info, and (opt-in) shell command execution.

Shell access is OFF unless data/config.json has "allow_shell": true —
enable it from the dashboard or by editing that file directly. Every
command run this way is appended to config.SHELL_AUDIT_LOG so there is
always a record of what ran and when. This exposes the same shell
Termux already gives you natively; nothing here reaches further than
your own Termux session.
"""

import os
import json
import socket
import shutil
import subprocess
from datetime import datetime

import psutil

from config import get_config, SHELL_AUDIT_LOG, DATA_DIR


class KernelController:

    def __init__(self):
        os.makedirs(DATA_DIR, exist_ok=True)

    # ─── Status ─────────────────────────────────────────────────
    def system_status(self):
        vm = psutil.virtual_memory()
        try:
            disk = psutil.disk_usage(os.path.expanduser("~"))
            disk_percent = disk.percent
        except Exception:
            disk_percent = "N/A"

        try:
            uptime = datetime.now() - datetime.fromtimestamp(psutil.boot_time())
            uptime_str = str(uptime).split(".")[0]
        except Exception:
            uptime_str = "N/A"

        return {
            "cpu_percent": psutil.cpu_percent(interval=0.3),
            "ram_percent": vm.percent,
            "ram_used": self._fmt_bytes(vm.used),
            "ram_total": self._fmt_bytes(vm.total),
            "disk_percent": disk_percent,
            "battery": self._battery_string(),
            "uptime": uptime_str,
            "temp": self._battery_temp(),
        }

    def _battery_string(self):
        info = self._termux_battery()
        if info:
            pct = info.get("percentage", "N/A")
            status = info.get("status", "")
            return f"{pct}% ({status.lower()})" if status else f"{pct}%"
        return "N/A (needs Termux:API)"

    def _battery_temp(self):
        info = self._termux_battery()
        if info and "temperature" in info:
            return f"{info['temperature']}°C"
        return "N/A"

    def _termux_battery(self):
        if not shutil.which("termux-battery-status"):
            return None
        try:
            out = subprocess.run(["termux-battery-status"], capture_output=True,
                                  text=True, timeout=5)
            return json.loads(out.stdout)
        except Exception:
            return None

    def _fmt_bytes(self, n):
        for unit in ["B", "KB", "MB", "GB"]:
            if n < 1024:
                return f"{n:.1f}{unit}"
            n /= 1024
        return f"{n:.1f}TB"

    # ─── Processes ──────────────────────────────────────────────
    def list_processes(self, limit=15):
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                info = p.info
                procs.append({
                    "pid": info["pid"],
                    "name": info["name"] or "?",
                    "cpu": info["cpu_percent"] or 0.0,
                    "mem": info["memory_percent"] or 0.0,
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda x: x["cpu"], reverse=True)
        return procs[:limit]

    def kill_process(self, target):
        try:
            pid = int(target)
            p = psutil.Process(pid)
            name = p.name()
            p.terminate()
            return f"Terminated process {name} (PID {pid})."
        except ValueError:
            killed = []
            for p in psutil.process_iter(["pid", "name"]):
                if p.info["name"] and target.lower() in p.info["name"].lower():
                    try:
                        p.terminate()
                        killed.append(f"{p.info['name']} (PID {p.info['pid']})")
                    except Exception:
                        pass
            if killed:
                return "Terminated: " + ", ".join(killed)
            return f"No running process matching '{target}' found. Note: SPIX1 can only stop processes it has permission to (its own, or ones you started from the same Termux session)."
        except psutil.NoSuchProcess:
            return f"No process with PID {target} found."
        except Exception as e:
            return f"Couldn't stop that process: {e}"

    # ─── Network ────────────────────────────────────────────────
    def network_status(self):
        hostname = socket.gethostname()
        try:
            ip = socket.gethostbyname(hostname)
        except Exception:
            ip = self._ip_via_socket_trick()

        interfaces = []
        try:
            interfaces = list(psutil.net_if_addrs().keys())
        except Exception:
            pass

        connected = ip not in (None, "127.0.0.1")
        return {
            "connected": connected,
            "ip": ip or "N/A",
            "hostname": hostname,
            "interfaces": interfaces or ["N/A"],
        }

    def _ip_via_socket_trick(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return None

    # ─── Shell (opt-in) ─────────────────────────────────────────
    def run_shell(self, cmd):
        cfg = get_config()
        if not cfg.get("allow_shell", False):
            return ("Shell access is turned off. Enable \"allow_shell\" in the "
                     "dashboard's settings panel (or data/config.json) if you "
                     "want SPIX1 to run shell commands you give it.")
        if not cmd or not cmd.strip():
            return "I need an actual command to run."

        self._audit(cmd)
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True,
                                     text=True, timeout=20, cwd=os.path.expanduser("~"))
            out = (result.stdout or "") + (result.stderr or "")
            out = out.strip() or "(no output)"
            if len(out) > 1500:
                out = out[:1500] + "\n… (truncated)"
            return f"```\n{out}\n```"
        except subprocess.TimeoutExpired:
            return "That command timed out after 20 seconds."
        except Exception as e:
            return f"Error running that command: {e}"

    def _audit(self, cmd):
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(SHELL_AUDIT_LOG, "a") as f:
                f.write(f"{datetime.now().isoformat()}\t{cmd}\n")
        except Exception:
            pass
