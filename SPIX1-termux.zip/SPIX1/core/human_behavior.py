"""
SPIX1 — Human Behavior Module
Simulates emotional state, personality, memory, and adaptive responses.
"""

import random
import threading
from datetime import datetime


class HumanBehavior:
    """Models human-like emotional and behavioral responses."""

    MOODS = ["neutral", "happy", "curious", "focused", "concerned",
             "excited", "calm", "thoughtful"]

    MOOD_DECORATORS = {
        "happy": [" 😊", " Great! ", " I'm glad to help! "],
        "curious": [" 🤔", " Interesting! ", " Hmm, let me think... "],
        "focused": ["", " Got it. ", " On it. "],
        "concerned": ["", " I hope everything is okay. ", " Let me help with that. "],
        "excited": [" 🎉", " Awesome! ", " Let's do this! "],
        "calm": ["", " Sure. ", " No problem. "],
        "thoughtful": ["", " Let's consider this carefully. ", " Good question. "],
        "neutral": ["", "", ""],
    }

    def __init__(self):
        self._mood = "neutral"
        self._mood_intensity = 0.5
        self._emotion_history = []
        self._lock = threading.Lock()

    def set_mood(self, mood):
        if mood in self.MOODS:
            self._mood = mood

    def get_mood(self):
        return self._mood

    def observe(self, sentiment, text):
        """Adjust mood based on user sentiment and input."""
        with self._lock:
            if sentiment == "positive":
                self._shift_mood("happy")
            elif sentiment == "negative":
                self._shift_mood("concerned")

            # Curiosity triggers
            question_words = ["why", "how", "what", "when", "where", "who"]
            if any(text.lower().startswith(w) for w in question_words):
                self._shift_mood("curious")

            # Excitement triggers
            if "!" in text or any(w in text.lower() for w in
                                 ["amazing", "awesome", "love", "wow"]):
                self._shift_mood("excited")

            self._emotion_history.append({
                "time": datetime.now().isoformat(),
                "mood": self._mood,
                "sentiment": sentiment,
            })
            # Keep history bounded
            if len(self._emotion_history) > 200:
                self._emotion_history = self._emotion_history[-100:]

    def _shift_mood(self, new_mood):
        """Gradually shift mood with some randomness for human feel."""
        if random.random() > 0.3:
            self._mood = new_mood

    def decorate(self, response, sentiment="neutral"):
        """Add personality and emotional flavor to a response."""
        decorators = self.MOOD_DECORATORS.get(self._mood,
                                              self.MOOD_DECORATORS["neutral"])
        flavor = random.choice(decorators)
        if flavor:
            response = f"{flavor.strip()} {response}"
        return response.strip()

    def get_emotion_history(self):
        return list(self._emotion_history)

    def personality_profile(self):
        """Return current personality profile."""
        return {
            "mood": self._mood,
            "intensity": self._mood_intensity,
            "history_size": len(self._emotion_history),
            "traits": ["helpful", "curious", "adaptive", "friendly"],
        }
