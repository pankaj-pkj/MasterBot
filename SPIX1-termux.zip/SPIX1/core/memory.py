"""
SPIX1 — Memory Store
Persistent long-term and short-term memory for the AI.
"""

import os
import json
import threading
from datetime import datetime

from config import MEMORY_FILE, MAX_MEMORY_ENTRIES, USER_CONFIG_FILE


class MemoryStore:
    """Manages conversations, user preferences, and long-term memory."""

    def __init__(self):
        self.conversations = []
        self.user_prefs = {}
        self.facts = []
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        if os.path.exists(MEMORY_FILE):
            try:
                with open(MEMORY_FILE, "r") as f:
                    data = json.load(f)
                self.conversations = data.get("conversations", [])
                self.user_prefs = data.get("user_prefs", {})
                self.facts = data.get("facts", [])
            except Exception:
                pass

    def _save(self):
        try:
            with open(MEMORY_FILE, "w") as f:
                json.dump({
                    "conversations": self.conversations[-MAX_MEMORY_ENTRIES:],
                    "user_prefs": self.user_prefs,
                    "facts": self.facts,
                }, f, indent=2)
        except Exception:
            pass

    def log_interaction(self, role, text, timestamp=None):
        with self._lock:
            self.conversations.append({
                "role": role,
                "text": text,
                "timestamp": timestamp or datetime.now().isoformat(),
            })
            if len(self.conversations) > MAX_MEMORY_ENTRIES:
                self.conversations = self.conversations[-MAX_MEMORY_ENTRIES:]
            self._save()

    def get_user_name(self):
        return self.user_prefs.get("name")

    def set_user_name(self, name):
        self.user_prefs["name"] = name
        self._save()

    def remember_fact(self, key, value):
        with self._lock:
            self.facts.append({
                "key": key,
                "value": value,
                "timestamp": datetime.now().isoformat(),
            })
            self._save()

    def recall_fact(self, key):
        for fact in reversed(self.facts):
            if fact["key"].lower() == key.lower():
                return fact["value"]
        return None

    def get_recent_conversations(self, limit=20):
        return self.conversations[-limit:]

    def count(self):
        return len(self.conversations)

    def clear_conversations(self):
        with self._lock:
            self.conversations = []
            self._save()

    def export(self):
        return {
            "conversations": self.conversations,
            "user_prefs": self.user_prefs,
            "facts": self.facts,
        }
