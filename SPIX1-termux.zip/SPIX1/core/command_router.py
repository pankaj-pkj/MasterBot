"""
SPIX1 — Command Router
Routes detected intents to the appropriate system action handlers.
"""

import os
import time
from datetime import datetime

from config import Colors


class CommandRouter:
    """Routes intents to action handlers."""

    def __init__(self, engine):
        self.engine = engine
        self.kernel = None
        self._init_handlers()

    def _init_handlers(self):
        from system.file_manager import FileManager
        from system.app_manager import AppManager
        from system.messaging import MessagingManager
        from system.alarm_manager import AlarmManager
        self.file_manager = FileManager()
        self.app_manager = AppManager()

    def route(self, intent, entities, raw_input, analysis):
        """Dispatch intent to the right handler."""
        handler = self.HANDLERS.get(intent)
        if handler:
            try:
                return handler(self, entities, raw_input)
            except Exception as e:
                return f"I encountered an error handling that request: {e}"
        return "I'm not sure how to handle that yet, but I'm learning."

    # ─── Individual Handlers ──────────────────────────────────

    def _handle_greet(self, entities, raw):
        import random
        return random.choice([
            "Hello! How can I help you?",
            "Hi there! What can I do for you?",
            "Hey! I'm ready to assist.",
        ])

    def _handle_set_alarm(self, entities, raw):
        if self.engine.alarm_manager:
            return self.engine.alarm_manager.set_alarm_from_command(raw, entities)
        return "Alarm management is not available right now."

    def _handle_list_alarms(self, entities, raw):
        if self.engine.alarm_manager:
            alarms = self.engine.alarm_manager.list_alarms()
            if not alarms:
                return "You have no active alarms or reminders."
            lines = ["Here are your active alarms:"]
            for a in alarms:
                lines.append(f"  • {a['label']} at {a['time']}")
            return "\n".join(lines)
        return "Alarm management is not available."

    def _handle_send_message(self, entities, raw):
        from system.messaging import MessagingManager
        mgr = MessagingManager()
        return mgr.send(entities, raw)

    def _handle_make_call(self, entities, raw):
        from system.messaging import MessagingManager
        mgr = MessagingManager()
        return mgr.call(entities, raw)

    def _handle_open_app(self, entities, raw):
        return self.app_manager.open(entities, raw)

    def _handle_close_app(self, entities, raw):
        return self.app_manager.close(entities, raw)

    def _handle_create_file(self, entities, raw):
        return self.file_manager.create(entities, raw)

    def _handle_delete_file(self, entities, raw):
        return self.file_manager.delete(entities, raw)

    def _handle_read_file(self, entities, raw):
        return self.file_manager.read(entities, raw)

    def _handle_system_status(self, entities, raw):
        if self.engine.kernel:
            status = self.engine.kernel.system_status()
            return (f"System Status:\n"
                    f"  CPU: {status['cpu_percent']}%\n"
                    f"  RAM: {status['ram_percent']}% ({status['ram_used']} / {status['ram_total']})\n"
                    f"  Disk: {status['disk_percent']}%\n"
                    f"  Battery: {status.get('battery', 'N/A')}\n"
                    f"  Uptime: {status['uptime']}\n"
                    f"  Temperature: {status.get('temp', 'N/A')}")
        import psutil
        return f"CPU: {psutil.cpu_percent()}%, RAM: {psutil.virtual_memory().percent}%"

    def _handle_list_processes(self, entities, raw):
        if self.engine.kernel:
            procs = self.engine.kernel.list_processes(limit=15)
            lines = ["Top processes by CPU:"]
            for p in procs:
                lines.append(f"  {p['name']:<25} PID:{p['pid']:<8} CPU:{p['cpu']:.1f}% MEM:{p['mem']:.1f}%")
            return "\n".join(lines)
        return "Kernel access required to list processes."

    def _handle_kill_process(self, entities, raw):
        if self.engine.kernel:
            target = entities.get("target") or entities.get("numbers", [""])[0]
            if target:
                return self.engine.kernel.kill_process(target)
        return "I need a process name or PID to kill it."

    def _handle_shell_command(self, entities, raw):
        if self.engine.kernel:
            cmd = entities.get("command", "")
            if cmd:
                return self.engine.kernel.run_shell(cmd)
        return "Shell command execution requires kernel access."

    def _handle_network_status(self, entities, raw):
        if self.engine.kernel:
            net = self.engine.kernel.network_status()
            return (f"Network Status:\n"
                    f"  Connected: {net['connected']}\n"
                    f"  IP Address: {net['ip']}\n"
                    f"  Hostname: {net['hostname']}\n"
                    f"  Interfaces: {', '.join(net['interfaces'])}")
        return "Network information requires kernel access."

    def _handle_time(self, entities, raw):
        return f"The current time is {datetime.now().strftime('%I:%M %p')}."

    def _handle_date(self, entities, raw):
        return f"Today is {datetime.now().strftime('%A, %B %d, %Y')}."

    def _handle_search(self, entities, raw):
        from system.knowledge_source import KnowledgeSource
        ks = KnowledgeSource()
        query = raw.replace("search", "").replace("wikipedia", "").strip()
        return ks.search(query)

    def _handle_api_query(self, entities, raw):
        if self.engine.api_manager and self.engine.api_manager.is_enabled():
            query = raw.replace("ask api", "").replace("use api", "").strip()
            return self.engine.api_manager.query(query)
        return ("External API is not enabled. You can enable it in the API section "
                "of the dashboard. I can still help with my built-in capabilities!")

    def _handle_self_learn(self, entities, raw):
        # "remember that X is Y" / "learn that ..."
        if "remember that" in raw.lower():
            fact = raw.lower().split("remember that", 1)[1].strip()
            parts = fact.split(" is ", 1)
            if len(parts) == 2:
                self.engine.memory.remember_fact(parts[0].strip(), parts[1].strip())
                return f"Got it! I'll remember that {parts[0].strip()} is {parts[1].strip()}."
            self.engine.memory.remember_fact("note", fact)
            return f"I've remembered that: {fact}"
        return "Tell me what to remember, like: 'remember that the sky is blue'."

    def _handle_set_name(self, entities, raw):
        name = entities.get("name")
        if name:
            self.engine.memory.set_user_name(name.capitalize())
            return f"Nice to meet you, {name.capitalize()}! I'll remember your name."
        return "I didn't catch your name. Try: 'my name is John'."

    def _handle_exit(self, entities, raw):
        return "Goodbye! Type 'exit' to shut me down."

    # ─── Handler Map ──────────────────────────────────────────
    HANDLERS = {
        "greet": _handle_greet,
        "set_alarm": _handle_set_alarm,
        "list_alarms": _handle_list_alarms,
        "send_message": _handle_send_message,
        "make_call": _handle_make_call,
        "open_app": _handle_open_app,
        "close_app": _handle_close_app,
        "create_file": _handle_create_file,
        "delete_file": _handle_delete_file,
        "read_file": _handle_read_file,
        "system_status": _handle_system_status,
        "list_processes": _handle_list_processes,
        "kill_process": _handle_kill_process,
        "shell_command": _handle_shell_command,
        "network_status": _handle_network_status,
        "time": _handle_time,
        "date": _handle_date,
        "search": _handle_search,
        "api_query": _handle_api_query,
        "self_learn": _handle_self_learn,
        "set_name": _handle_set_name,
        "exit": _handle_exit,
    }
