"""
SPIX1 — Core AI Engine
The central brain that orchestrates NLP, learning, memory, behavior,
intent routing, and all system commands.
"""

import os
import json
import time
import random
import threading
from datetime import datetime

from config import (
    AI_NAME, AI_VERSION, LEARNING_ENABLED, CONFIDENCE_THRESHOLD,
    KNOWLEDGE_FILE, MEMORY_FILE, Colors
)


class AIEngine:
    """The main SPIX1 AI brain."""

    def __init__(self):
        self.tts = None
        self.stt = None
        self.kernel = None
        self.socketio = None
        self.alarm_manager = None
        self.api_manager = None
        self.behavior = None
        self.learning = None
        self.nlp = None
        self.command_router = None

        self.start_time = datetime.now()
        self.interaction_count = 0
        self._lock = threading.Lock()

        # Load subsystems
        from core.nlp_processor import NLPProcessor
        from core.self_learning import SelfLearning
        from core.human_behavior import HumanBehavior
        from core.command_router import CommandRouter
        from core.memory import MemoryStore

        self.memory = MemoryStore()
        self.nlp = NLPProcessor()
        self.learning = SelfLearning(self.memory)
        self.behavior = HumanBehavior()
        self.command_router = CommandRouter(self)

        # Restore personality
        self.behavior.set_mood("neutral")

    # ─── Subsystem Attachers ───────────────────────────────────
    def attach_tts(self, tts):
        self.tts = tts

    def attach_stt(self, stt):
        self.stt = stt

    def attach_kernel(self, kernel):
        self.kernel = kernel

    def attach_socketio(self, sio):
        self.socketio = sio

    def attach_alarm_manager(self, am):
        self.alarm_manager = am

    def attach_api_manager(self, api):
        self.api_manager = api

    # ─── Emit event to web clients ────────────────────────────
    def emit(self, event, data):
        if self.socketio:
            try:
                self.socketio.emit(event, data, namespace="/")
            except Exception:
                pass

    # ─── Greeting ─────────────────────────────────────────────
    def greet(self):
        hour = datetime.now().hour
        if hour < 12:
            greeting = "Good morning"
        elif hour < 18:
            greeting = "Good afternoon"
        else:
            greeting = "Good evening"
        name = self.memory.get_user_name() or ""
        mood = self.behavior.get_mood()
        if mood == "happy":
            extra = " I'm feeling great today!"
        elif mood == "curious":
            extra = " I'm curious about what we'll work on."
        else:
            extra = ""
        if name:
            return f"{greeting}, {name}! I'm {AI_NAME}, version {AI_VERSION}.{extra} How can I help you?"
        return f"{greeting}! I'm {AI_NAME}, version {AI_VERSION}.{extra} How can I help you?"

    # ─── Main processing pipeline ─────────────────────────────
    def process(self, user_input, source="text"):
        with self._lock:
            self.interaction_count += 1
            timestamp = datetime.now().isoformat()

            # Log interaction to memory
            self.memory.log_interaction("user", user_input, timestamp)

            # NLP analysis
            analysis = self.nlp.analyze(user_input)
            intent = analysis.get("intent", "chat")
            entities = analysis.get("entities", {})
            sentiment = analysis.get("sentiment", "neutral")

            # Update emotional state
            self.behavior.observe(sentiment, user_input)

            # Route command or chat
            if intent != "chat":
                response = self.command_router.route(intent, entities, user_input, analysis)
            else:
                # Try to answer from learned knowledge
                learned = self.learning.retrieve(user_input)
                if learned and learned["confidence"] >= CONFIDENCE_THRESHOLD:
                    response = learned["answer"]
                    response = self.behavior.decorate(response, sentiment)
                elif self.api_manager and self.api_manager.is_enabled():
                    response = self.api_manager.query(user_input)
                    response = self.behavior.decorate(response, sentiment)
                else:
                    response = self._generate_local_response(user_input, analysis)
                    response = self.behavior.decorate(response, sentiment)

            # Learn from interaction
            if LEARNING_ENABLED:
                self.learning.learn(user_input, response, analysis)

            # Log AI response
            self.memory.log_interaction("ai", response, timestamp)

            # Emit to web
            self.emit("ai_response", {
                "text": response,
                "intent": intent,
                "sentiment": sentiment,
                "mood": self.behavior.get_mood(),
                "timestamp": timestamp,
            })

            return response

    # ─── Local response generation ────────────────────────────
    def _generate_local_response(self, user_input, analysis):
        """Generate a context-aware response without external APIs."""
        # Greetings
        lower = user_input.lower().strip()
        greetings = ["hello", "hi", "hey", "greetings", "yo", "howdy"]
        if any(lower.startswith(g) for g in greetings):
            return random.choice([
                "Hello! What can I do for you?",
                "Hi there! How can I assist you?",
                "Hey! I'm here and ready to help.",
            ])

        # How are you
        if "how are you" in lower or "how do you feel" in lower:
            mood = self.behavior.get_mood()
            return f"I'm feeling {mood} today. Thanks for asking! What about you?"

        # Who are you
        if "who are you" in lower or "what are you" in lower:
            return (f"I'm {AI_NAME}, an advanced self-learning AI assistant. "
                    f"I can talk, listen, manage files, set alarms, send messages, "
                    f"make calls, open apps, and control your system at the kernel level.")

        # Time
        if "what time" in lower or "current time" in lower:
            now = datetime.now().strftime("%I:%M %p")
            return f"The current time is {now}."

        # Date
        if "what day" in lower or "today's date" in lower or "what date" in lower:
            today = datetime.now().strftime("%A, %B %d, %Y")
            return f"Today is {today}."

        # Capabilities
        if "what can you do" in lower or "help me" in lower or "your features" in lower:
            return (f"I can do a lot! Here are some things:\n"
                    f"• Talk and listen to you\n"
                    f"• Set alarms and reminders\n"
                    f"• Send messages and make calls\n"
                    f"• Create, read, delete files\n"
                    f"• Open and close applications\n"
                    f"• Kernel-level system control\n"
                    f"• Self-learn from our conversations\n"
                    f"• Connect to external APIs (optional)\n"
                    f"Just ask me naturally!")

        # Thanks
        if "thank" in lower:
            return random.choice([
                "You're welcome! Happy to help.",
                "Anytime! That's what I'm here for.",
                "My pleasure!",
            ])

        # Math
        if analysis.get("has_math"):
            result = self._safe_math(user_input)
            if result is not None:
                return f"The answer is {result}."

        # Default — conversational fallback that learns
        return random.choice([
            f"I understand you said: '{user_input}'. Tell me more, or ask me to do something specific.",
            f"That's interesting. I'm learning from this. Could you elaborate?",
            f"I noted that. Is there something specific you'd like me to do about it?",
            f"I'm processing that. What would you like me to do next?",
        ])

    # ─── Safe math evaluator ──────────────────────────────────
    def _safe_math(self, expr):
        try:
            import re
            clean = re.findall(r'[0-9\+\-\*\/\(\)\.\%\^ ]+', expr)
            if not clean:
                return None
            math_expr = clean[0].replace('^', '**')
            if not any(c.isdigit() for c in math_expr):
                return None
            result = eval(math_expr, {"__builtins__": {}}, {})
            return round(result, 6) if isinstance(result, float) else result
        except Exception:
            return None

    # ─── Status report ────────────────────────────────────────
    def status(self):
        uptime = datetime.now() - self.start_time
        return {
            "name": AI_NAME,
            "version": AI_VERSION,
            "uptime_seconds": int(uptime.total_seconds()),
            "interactions": self.interaction_count,
            "mood": self.behavior.get_mood(),
            "knowledge_entries": self.learning.count(),
            "memory_entries": self.memory.count(),
            "voice": self.tts is not None,
            "kernel": self.kernel is not None,
            "api": self.api_manager.is_enabled() if self.api_manager else False,
        }
