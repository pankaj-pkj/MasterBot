"""
SPIX1 — API Manager
Optional reasoning backend, used only as a fallback when the built-in
offline matcher (core/self_learning.py) isn't confident it has a good
answer. Fully optional — SPIX1 runs with this disabled by default.

provider = "none"      offline rule-based matching only (default)
provider = "local"     a small GGUF model you run yourself via
                        llama.cpp's `llama-server` on-device — still no
                        internet, still no API key (see setup_termux.sh)
provider = "anthropic" Claude API, your own key
provider = "openai"    OpenAI-compatible API, your own key
provider = "custom"    any OpenAI-chat-compatible endpoint you point it at

Toggle and configure this from the web dashboard's API panel, or by
editing data/config.json directly.
"""

from config import get_config, LOCAL_LLM_URL, API_TIMEOUT


class APIManager:
    def __init__(self, memory=None):
        self.memory = memory
        self._reload()

    def _reload(self):
        cfg = get_config()
        self.enabled = bool(cfg.get("api_enabled"))
        self.provider = cfg.get("api_provider", "none")
        self.api_key = cfg.get("api_key", "")
        self.model = cfg.get("api_model", "")
        self.base_url = cfg.get("api_base_url", "")
        self.local_url = cfg.get("local_llm_url") or LOCAL_LLM_URL

    def is_enabled(self):
        # Re-read config each time so dashboard changes apply without a restart.
        self._reload()
        if not self.enabled or self.provider in ("none", ""):
            return False
        if self.provider in ("anthropic", "openai") and not self.api_key:
            return False
        return True

    def query(self, text):
        self._reload()
        try:
            if self.provider == "local":
                return self._query_local(text)
            if self.provider == "anthropic":
                return self._query_anthropic(text)
            if self.provider == "openai":
                return self._query_openai(text)
            if self.provider == "custom":
                return self._query_custom(text)
        except Exception as e:
            return (f"I couldn't reach the {self.provider} reasoning backend "
                    f"({e}). Falling back to my built-in responses.")
        return "No reasoning backend is configured."

    # ─── Shared context builder ────────────────────────────────
    def _context_messages(self, limit=6):
        """Pull a little recent chat history so replies stay coherent."""
        msgs = []
        if self.memory:
            try:
                for turn in self.memory.get_recent_conversations(limit=limit):
                    role = "assistant" if turn.get("role") == "ai" else "user"
                    msgs.append({"role": role, "content": turn.get("text", "")})
            except Exception:
                pass
        return msgs

    # ─── Local on-device model (llama.cpp server) ──────────────
    def _query_local(self, text):
        import requests
        messages = self._context_messages() + [{"role": "user", "content": text}]
        resp = requests.post(
            f"{self.local_url}/v1/chat/completions",
            json={"messages": messages, "temperature": 0.7, "max_tokens": 400},
            timeout=API_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()

    # ─── Anthropic (Claude API) ─────────────────────────────────
    def _query_anthropic(self, text):
        import requests
        model = self.model or "claude-haiku-4-5-20251001"
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": model,
                "max_tokens": 400,
                "messages": self._context_messages() + [{"role": "user", "content": text}],
            },
            timeout=API_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
        return "".join(b.get("text", "") for b in data.get("content", [])).strip()

    # ─── OpenAI-compatible ───────────────────────────────────────
    def _query_openai(self, text):
        import requests
        model = self.model or "gpt-4o-mini"
        resp = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={
                "model": model,
                "messages": self._context_messages() + [{"role": "user", "content": text}],
            },
            timeout=API_TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()

    # ─── Any custom OpenAI-chat-compatible endpoint ─────────────
    def _query_custom(self, text):
        import requests
        if not self.base_url:
            return "Custom provider selected but no base_url is set in config.json."
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        resp = requests.post(
            self.base_url.rstrip("/") + "/chat/completions",
            headers=headers,
            json={
                "model": self.model or "default",
                "messages": self._context_messages() + [{"role": "user", "content": text}],
            },
            timeout=API_TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"].strip()
