"""
SPIX1 — NLP Processor
Natural Language Processing using local rule-based + statistical methods.
No external API required.
"""

import re
import string
from collections import Counter


class NLPProcessor:
    """Local NLP engine for intent detection, entity extraction, and analysis."""

    # Intent patterns
    INTENT_PATTERNS = {
        "greet": [r"^(hi|hello|hey|greetings|howdy|yo)\b"],
        "set_alarm": [r"\b(set|create)\b.*\b(alarm|reminder)\b",
                      r"\bremind me\b", r"\bwake me\b"],
        "list_alarms": [r"\b(list|show|what).*(alarms?|reminders?)\b"],
        "send_message": [r"\b(send|text|message)\b.*\b(to|at|@)?\b"],
        "make_call": [r"\b(call|dial|phone)\b"],
        "open_app": [r"\b(open|launch|start|run)\b.*\b(app|application|program)\b",
                     r"\b(open|launch|start)\b\s+\w+"],
        "close_app": [r"\b(close|kill|exit|terminate|stop)\b.*\b(app|application|program|process)\b"],
        "create_file": [r"\b(create|make|new)\b.*\b(file|document|folder|directory)\b",
                         r"\b(create|make|new)\s+[\w\-]+\.\w{1,5}\b"],
        "delete_file": [r"\b(delete|remove|erase|destroy)\b.*\b(file|folder|directory|document)\b",
                         r"\b(delete|remove|erase)\s+[\w\-]+\.\w{1,5}\b"],
        "read_file": [r"\b(read|show|display|open)\b.*\b(file|content|document)\b",
                      r"\b(read|show|display)\s+[\w\-]+\.\w{1,5}\b"],
        "network_status": [r"\b(network|wifi|internet|connection|ip address)\b"],
        "system_status": [r"\b(system|cpu|ram|memory|disk|battery|status|health)\b"],
        "list_processes": [r"\b(list|show|running)\b.*\b(processes?|apps?)\b"],
        "kill_process": [r"\b(kill|stop|end|terminate)\b.*\bprocess\b"],
        "shell_command": [r"\b(run|execute|cmd|command|terminal)\b.*\b(command|cmd)?\b"],
        "weather": [r"\b(weather|temperature|forecast)\b"],
        "time": [r"\bwhat time\b", r"\bcurrent time\b", r"\btell me the time\b"],
        "date": [r"\bwhat (day|date)\b", r"\btoday'?s date\b", r"\bwhat is the date\b"],
        "search": [r"\b(search|google|look up|find|wikipedia)\b"],
        "api_query": [r"\b(ask api|use api|external ai)\b"],
        "self_learn": [r"\b(learn|remember|memorize|teach)\b.*\b(that|this)?\b"],
        "set_name": [r"\b(my name is|call me|i am|i'm)\b"],
        "exit": [r"\b(exit|quit|shutdown|goodbye|bye)\b"],
    }

    # Math detection
    MATH_PATTERN = re.compile(r'[\d\.\+\-\*\/\(\)\%\^ ]+')

    def __init__(self):
        self._stopwords = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "could", "should", "may", "might", "must", "shall",
            "can", "need", "dare", "ought", "used", "to", "of", "in",
            "for", "on", "with", "at", "by", "from", "as", "into",
            "through", "during", "before", "after", "above", "below",
            "up", "down", "out", "off", "over", "under", "again",
            "further", "then", "once", "and", "but", "or", "if", "because",
            "until", "while", "about", "against", "between", "into",
            "i", "you", "he", "she", "it", "we", "they", "me", "him",
            "her", "us", "them", "my", "your", "his", "its", "our", "their",
        }

    def analyze(self, text):
        """Full analysis of input text."""
        text_lower = text.lower().strip()
        tokens = self._tokenize(text_lower)
        intent = self._detect_intent(text_lower)
        entities = self._extract_entities(text, intent)
        sentiment = self._detect_sentiment(text_lower)
        keywords = self._extract_keywords(tokens)

        return {
            "original": text,
            "tokens": tokens,
            "intent": intent,
            "entities": entities,
            "sentiment": sentiment,
            "keywords": keywords,
            "has_math": self._has_math(text_lower),
        }

    def _tokenize(self, text):
        tokens = re.findall(r"\b\w+\b", text)
        return tokens

    def _detect_intent(self, text):
        for intent, patterns in self.INTENT_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, text):
                    return intent
        return "chat"

    def _extract_entities(self, text, intent):
        """Extract entities relevant to the detected intent."""
        entities = {}
        original = text

        # Extract quoted strings
        quotes = re.findall(r'["\']([^"\']+)["\']', original)
        if quotes:
            entities["quoted"] = quotes

        # Numbers
        numbers = re.findall(r'\b\d+\b', original)
        if numbers:
            entities["numbers"] = numbers

        # Times (for alarms)
        time_match = re.search(
            r'\b(\d{1,2}):(\d{2})\s*(am|pm)?\b', original, re.IGNORECASE)
        if time_match:
            entities["time"] = time_match.group(0).strip()
        else:
            # "at 5", "at 5pm", "in 10 minutes"
            at_match = re.search(r'\bat\s+(\d{1,2})(am|pm)?\b', original, re.IGNORECASE)
            if at_match:
                entities["time"] = at_match.group(0).replace("at ", "").strip()
            in_match = re.search(r'\bin\s+(\d+)\s*(minutes?|mins?|hours?|hrs?)\b', original, re.IGNORECASE)
            if in_match:
                entities["duration"] = in_match.group(0).replace("in ", "").strip()

        # File / app names
        if intent == "open_app":
            # "open notepad", "launch chrome"
            match = re.search(r'(?:open|launch|start|run)\s+(.+)', original, re.IGNORECASE)
            if match:
                target = match.group(1).strip()
                # remove trailing words like "app", "application"
                target = re.sub(r'\s+(app|application|program)$', '', target, flags=re.IGNORECASE)
                entities["target"] = target

        if intent == "close_app":
            match = re.search(r'(?:close|kill|exit|terminate|stop)\s+(.+)', original, re.IGNORECASE)
            if match:
                entities["target"] = match.group(1).strip()

        if intent in ("create_file", "delete_file", "read_file"):
            # Extract filename — prefer quoted, else after "file/folder called"
            match = re.search(r'(?:called|named|file|folder|directory)\s*[:\-]?\s*(.+)', original, re.IGNORECASE)
            if match:
                name = match.group(1).strip().strip('"\'')
                entities["filename"] = name
            elif quotes:
                entities["filename"] = quotes[0]

        if intent == "send_message":
            match = re.search(r'(?:to|at|@)\s*(\+?\d[\d\s\-]+|\w+)', original, re.IGNORECASE)
            if match:
                entities["recipient"] = match.group(1).strip()
            if quotes:
                entities["message"] = quotes[0]

        if intent == "make_call":
            match = re.search(r'(?:call|dial|phone)\s+(\+?\d[\d\s\-]+|\w+)', original, re.IGNORECASE)
            if match:
                entities["recipient"] = match.group(1).strip()

        if intent == "set_name":
            match = re.search(r'(?:my name is|call me|i am|i\'m)\s+(\w+)', original, re.IGNORECASE)
            if match:
                entities["name"] = match.group(1).strip()

        if intent == "shell_command":
            match = re.search(r'(?:run|execute|cmd|command|terminal)\s*[:\-]?\s*(.+)', original, re.IGNORECASE)
            if match:
                entities["command"] = match.group(1).strip()

        return entities

    def _detect_sentiment(self, text):
        positive = ["good", "great", "awesome", "excellent", "happy", "love",
                    "wonderful", "amazing", "fantastic", "nice", "thanks",
                    "thank", "cool", "perfect", "best", "glad", "pleased"]
        negative = ["bad", "terrible", "awful", "hate", "angry", "sad",
                    "stupid", "wrong", "error", "fail", "broken", "horrible",
                    "worst", "annoyed", "frustrated"]
        score = 0
        for word in positive:
            if word in text:
                score += 1
        for word in negative:
            if word in text:
                score -= 1
        if score > 0:
            return "positive"
        if score < 0:
            return "negative"
        return "neutral"

    def _extract_keywords(self, tokens):
        meaningful = [t for t in tokens if t not in self._stopwords and len(t) > 2]
        return meaningful

    def _has_math(self, text):
        if re.search(r'\d+\s*[\+\-\*\/\^]\s*\d+', text):
            return True
        if re.search(r'\b(plus|minus|times|divided by|multiplied by)\b', text):
            return True
        return False
