"""
SPIX1 — Self-Learning Module
Learns from every interaction, builds a persistent knowledge base,
and retrieves relevant answers without external APIs.
"""

import os
import json
import time
import threading
import re
from difflib import SequenceMatcher

from config import KNOWLEDGE_FILE, MAX_KNOWLEDGE_ENTRIES, FORGETTING_FACTOR


class SelfLearning:
    """Persistent self-learning knowledge store."""

    def __init__(self, memory):
        self.memory = memory
        self.knowledge = []
        self._lock = threading.Lock()
        self._load()

    def _load(self):
        if os.path.exists(KNOWLEDGE_FILE):
            try:
                with open(KNOWLEDGE_FILE, "r") as f:
                    self.knowledge = json.load(f)
            except Exception:
                self.knowledge = []

    def _save(self):
        try:
            with open(KNOWLEDGE_FILE, "w") as f:
                json.dump(self.knowledge, f, indent=2)
        except Exception:
            pass

    def learn(self, question, answer, analysis=None):
        """Store or reinforce a Q→A pair."""
        with self._lock:
            question_clean = question.lower().strip()
            keywords = analysis.get("keywords", []) if analysis else []

            # Check if similar question already exists
            for entry in self.knowledge:
                similarity = SequenceMatcher(None, question_clean,
                                            entry["question"]).ratio()
                if similarity > 0.85:
                    # Reinforce existing
                    entry["answer"] = answer
                    entry["confidence"] = min(1.0, entry["confidence"] + 0.1)
                    entry["times_seen"] = entry.get("times_seen", 0) + 1
                    entry["last_seen"] = time.time()
                    self._save()
                    return

            # New entry
            if len(self.knowledge) >= MAX_KNOWLEDGE_ENTRIES:
                # Remove lowest confidence entry
                self.knowledge.sort(key=lambda e: e.get("confidence", 0))
                self.knowledge.pop(0)

            self.knowledge.append({
                "question": question_clean,
                "answer": answer,
                "keywords": keywords,
                "confidence": 0.6,
                "times_seen": 1,
                "created": time.time(),
                "last_seen": time.time(),
            })
            self._save()

    def retrieve(self, question):
        """Find the best matching learned answer."""
        with self._lock:
            if not self.knowledge:
                return None

            question_clean = question.lower().strip()
            best_match = None
            best_score = 0.0

            for entry in self.knowledge:
                # Apply forgetting factor based on time
                age = time.time() - entry.get("last_seen", time.time())
                decay = FORGETTING_FACTOR ** (age / 86400)  # per day
                confidence = entry.get("confidence", 0.5) * decay

                # Similarity
                sim = SequenceMatcher(None, question_clean,
                                      entry["question"]).ratio()

                # Keyword overlap bonus
                q_words = set(re.findall(r"\w+", question_clean))
                k_words = set(entry.get("keywords", []))
                if q_words and k_words:
                    overlap = len(q_words & k_words) / len(q_words)
                else:
                    overlap = 0

                score = (sim * 0.6) + (overlap * 0.3) + (confidence * 0.1)

                if score > best_score:
                    best_score = score
                    best_match = entry

            if best_match and best_score > 0.45:
                # Reinforce
                best_match["last_seen"] = time.time()
                best_match["times_seen"] = best_match.get("times_seen", 1) + 1
                self._save()
                return {
                    "answer": best_match["answer"],
                    "confidence": best_match["confidence"],
                    "score": best_score,
                }
            return None

    def teach(self, question, answer):
        """Manually teach SPIX1 a fact."""
        self.learn(question, answer)
        return True

    def forget(self, question):
        """Remove knowledge matching a question."""
        with self._lock:
            before = len(self.knowledge)
            question_clean = question.lower().strip()
            self.knowledge = [
                e for e in self.knowledge
                if SequenceMatcher(None, question_clean,
                                   e["question"]).ratio() < 0.75
            ]
            self._save()
            return before - len(self.knowledge)

    def count(self):
        return len(self.knowledge)

    def export(self):
        with self._lock:
            return list(self.knowledge)

    def clear(self):
        with self._lock:
            self.knowledge = []
            self._save()
