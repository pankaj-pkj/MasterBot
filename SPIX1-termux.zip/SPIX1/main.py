"""
SPIX1 — Main Entry Point
Boots the AI engine, voice system, and web dashboard. Termux edition.
"""

import sys
import os
import threading

# Ensure project root is on the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    ensure_directories, BANNER, Colors, HOST, PORT, DEBUG,
    VOICE_ENABLED, get_config
)
from core.ai_engine import AIEngine
from core.api_manager import APIManager
from voice.speech_synthesis import TTSEngine
from voice.speech_recognition import STTEngine
from system.kernel_control import KernelController
from system.alarm_manager import AlarmManager
from web.server import create_app, socketio


def print_banner():
    cfg = get_config()
    print(f"{Colors.CYAN}{Colors.BOLD}{BANNER}{Colors.RESET}")
    print(f"{Colors.GREEN}  [✓] Core Engine      — Initialized")
    print(f"{Colors.GREEN}  [✓] Self-Learning    — Enabled")
    print(f"{Colors.GREEN}  [✓] Voice System     — {'Enabled' if VOICE_ENABLED else 'Disabled'} (Termux:API)")
    print(f"{Colors.GREEN}  [✓] System Info      — Enabled")
    shell_state = 'Enabled' if cfg.get('allow_shell') else 'Disabled (opt in via Settings)'
    print(f"{Colors.YELLOW if not cfg.get('allow_shell') else Colors.GREEN}  [{'✓' if cfg.get('allow_shell') else '·'}] Shell Commands   — {shell_state}")
    api_state = f"{cfg.get('api_provider')}" if cfg.get('api_enabled') else 'Off (offline, built-in only)'
    print(f"{Colors.GREEN}  [✓] Reasoning Backend — {api_state}")
    print(f"{Colors.GREEN}  [✓] Web Dashboard    — http://{HOST}:{PORT}")
    print(f"{Colors.MAGENTA}  {'─' * 50}")
    print(f"{Colors.YELLOW}  SPIX1 is online and listening.{Colors.RESET}\n")


def boot_spix1():
    """Initialize all SPIX1 subsystems."""
    ensure_directories()
    print_banner()

    # ─── Initialize core engine ────────────────────────────────
    print(f"{Colors.CYAN}[SPIX1] Booting AI engine...{Colors.RESET}")
    engine = AIEngine()

    # ─── Optional reasoning backend (local model or cloud API) ──
    api_manager = APIManager(memory=engine.memory)
    engine.attach_api_manager(api_manager)

    # ─── Initialize voice (Termux:API — best-effort) ────────────
    tts = None
    stt = None
    if VOICE_ENABLED:
        print(f"{Colors.CYAN}[SPIX1] Initializing voice systems...{Colors.RESET}")
        try:
            tts = TTSEngine()
            engine.attach_tts(tts)
        except Exception as e:
            print(f"{Colors.YELLOW}[SPIX1] TTS unavailable: {e}{Colors.RESET}")
        try:
            stt = STTEngine()
            engine.attach_stt(stt)
        except Exception as e:
            print(f"{Colors.YELLOW}[SPIX1] STT unavailable: {e}{Colors.RESET}")

    # ─── System info / gated shell control ───────────────────────
    # Always attached for status/process/network info; run_shell() itself
    # checks the allow_shell config flag before executing anything.
    kernel = KernelController()
    engine.attach_kernel(kernel)

    # ─── Alarm manager ───────────────────────────────────────────
    alarm_mgr = AlarmManager(engine)
    engine.attach_alarm_manager(alarm_mgr)
    alarm_mgr.start()

    # ─── Greet the user ────────────────────────────────────────
    greeting = engine.greet()
    print(f"\n{Colors.MAGENTA}[SPIX1] {greeting}{Colors.RESET}")
    if tts:
        threading.Thread(target=tts.speak, args=(greeting,), daemon=True).start()

    # ─── Start web dashboard ───────────────────────────────────
    app = create_app(engine)
    engine.attach_socketio(socketio)

    def run_web():
        socketio.run(app, host=HOST, port=PORT, debug=DEBUG, allow_unsafe_werkzeug=True)

    web_thread = threading.Thread(target=run_web, daemon=True)
    web_thread.start()

    # ─── CLI interaction loop ──────────────────────────────────
    print(f"\n{Colors.CYAN}[SPIX1] Type a command or 'talk' for voice mode. "
          f"Type 'exit' to quit.{Colors.RESET}\n")

    while True:
        try:
            user_input = input(f"{Colors.CYAN}You › {Colors.RESET}").strip()
            if not user_input:
                continue

            if user_input.lower() in ("exit", "quit", "shutdown"):
                print(f"{Colors.YELLOW}[SPIX1] Shutting down. Goodbye!{Colors.RESET}")
                if tts:
                    tts.speak("Shutting down. Goodbye!")
                alarm_mgr.stop()
                break

            if user_input.lower() == "talk":
                if stt:
                    print(f"{Colors.YELLOW}[SPIX1] Listening...{Colors.RESET}")
                    heard = stt.listen()
                    if heard:
                        print(f"{Colors.GREEN}You › {heard}{Colors.RESET}")
                        response = engine.process(heard)
                        print(f"{Colors.MAGENTA}SPIX1 › {response}{Colors.RESET}")
                        if tts:
                            tts.speak(response)
                    else:
                        print(f"{Colors.YELLOW}[SPIX1] Didn't catch that.{Colors.RESET}")
                else:
                    print(f"{Colors.RED}[SPIX1] Voice recognition not available.{Colors.RESET}")
                continue

            response = engine.process(user_input)
            print(f"{Colors.MAGENTA}SPIX1 › {response}{Colors.RESET}")
            if tts:
                threading.Thread(target=tts.speak, args=(response,), daemon=True).start()

        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}[SPIX1] Shutting down. Goodbye!{Colors.RESET}")
            if tts:
                tts.speak("Shutting down. Goodbye!")
            alarm_mgr.stop()
            break
        except Exception as e:
            print(f"{Colors.RED}[SPIX1] Error: {e}{Colors.RESET}")


if __name__ == "__main__":
    boot_spix1()
