"""
SPIX1 — Web Dashboard
A small single-file Flask + SocketIO app: chat, live status, and a
settings panel for the optional reasoning backend and shell toggle.

Bound to 127.0.0.1 by default (see config.py) — reachable from a
browser on the same phone, not from other devices on the network,
unless you deliberately change HOST.

Uses threading async mode instead of eventlet, which tends to be more
reliable to install under Termux.
"""

from flask import Flask, request, jsonify, render_template_string
from flask_socketio import SocketIO

from config import SECRET_KEY, get_config, save_config

socketio = SocketIO(async_mode="threading", cors_allowed_origins="*")

PAGE = """
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SPIX1</title>
<script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
<style>
  :root { color-scheme: dark; }
  body { margin:0; font-family: -apple-system, Roboto, sans-serif; background:#0f1115; color:#e6e6e6; }
  header { padding:14px 16px; background:#161a20; display:flex; justify-content:space-between; align-items:center; }
  header b { color:#7dd3fc; }
  #tabs { display:flex; background:#161a20; border-top:1px solid #23272f; }
  #tabs button { flex:1; padding:10px; background:none; border:none; color:#8a93a3; font-size:14px; }
  #tabs button.active { color:#7dd3fc; border-bottom:2px solid #7dd3fc; }
  .view { display:none; padding:12px; }
  .view.active { display:block; }
  #log { height:60vh; overflow-y:auto; padding:8px 4px; }
  .msg { margin:8px 0; padding:8px 12px; border-radius:12px; max-width:85%; white-space:pre-wrap; word-wrap:break-word; }
  .user { background:#2563eb; margin-left:auto; }
  .ai { background:#1f242e; }
  #inputRow { display:flex; gap:8px; padding:10px; position:sticky; bottom:0; background:#0f1115; }
  #inputRow input { flex:1; padding:10px; border-radius:8px; border:1px solid #2a2f3a; background:#161a20; color:#e6e6e6; }
  button.send { padding:10px 16px; border-radius:8px; border:none; background:#2563eb; color:white; }
  .stat { display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #23272f; font-size:14px; }
  label { display:block; margin:12px 0 4px; font-size:13px; color:#8a93a3; }
  input, select { width:100%; box-sizing:border-box; padding:8px; border-radius:6px; border:1px solid #2a2f3a; background:#161a20; color:#e6e6e6; }
  .save { margin-top:16px; padding:10px 16px; border-radius:8px; border:none; background:#2563eb; color:white; width:100%; }
  .hint { font-size:12px; color:#6b7280; margin-top:6px; }
</style>
</head>
<body>
<header><b>SPIX1</b><span id="mood" style="font-size:13px;color:#8a93a3;"></span></header>
<div id="tabs">
  <button class="active" onclick="showView('chat')">Chat</button>
  <button onclick="showView('status')">Status</button>
  <button onclick="showView('settings')">Settings</button>
</div>

<div id="chat" class="view active">
  <div id="log"></div>
  <div id="inputRow">
    <input id="msgInput" placeholder="Ask SPIX1 something…" onkeydown="if(event.key==='Enter')sendMsg()">
    <button class="send" onclick="sendMsg()">Send</button>
  </div>
</div>

<div id="status" class="view">
  <div id="statusBody">Loading…</div>
</div>

<div id="settings" class="view">
  <label>Reasoning backend</label>
  <select id="provider">
    <option value="none">Off — built-in only</option>
    <option value="local">Local model (llama.cpp on-device)</option>
    <option value="anthropic">Anthropic (Claude API)</option>
    <option value="openai">OpenAI-compatible</option>
    <option value="custom">Custom endpoint</option>
  </select>
  <label>API key (blank for local)</label>
  <input id="apiKey" type="password" placeholder="sk-…">
  <label>Model name (optional)</label>
  <input id="apiModel" placeholder="e.g. claude-haiku-4-5-20251001">
  <label>Base URL (local / custom only)</label>
  <input id="baseUrl" placeholder="http://127.0.0.1:8080">
  <label style="display:flex;align-items:center;gap:8px;margin-top:16px;">
    <input type="checkbox" id="allowShell" style="width:auto;"> Allow shell commands via chat
  </label>
  <div class="hint">Off by default. Termux already gives you a full shell natively — this only lets SPIX1 run commands you ask it to, through chat, with everything logged to data/shell_audit.log.</div>
  <button class="save" onclick="saveSettings()">Save</button>
</div>

<script>
const socket = io();
const log = document.getElementById('log');

function addMsg(text, who) {
  const d = document.createElement('div');
  d.className = 'msg ' + who;
  d.textContent = text;
  log.appendChild(d);
  log.scrollTop = log.scrollHeight;
}

function sendMsg() {
  const input = document.getElementById('msgInput');
  const text = input.value.trim();
  if (!text) return;
  addMsg(text, 'user');
  input.value = '';
  socket.emit('user_message', {text});
}

socket.on('ai_response', (data) => {
  addMsg(data.text, 'ai');
  document.getElementById('mood').textContent = data.mood ? ('mood: ' + data.mood) : '';
});

function showView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('#tabs button').forEach(b => b.classList.remove('active'));
  document.getElementById(name).classList.add('active');
  event.target.classList.add('active');
  if (name === 'status') loadStatus();
  if (name === 'settings') loadSettings();
}

function loadStatus() {
  fetch('/api/status').then(r => r.json()).then(s => {
    document.getElementById('statusBody').innerHTML = Object.entries(s)
      .map(([k, v]) => `<div class="stat"><span>${k}</span><span>${v}</span></div>`).join('');
  });
}

function loadSettings() {
  fetch('/api/config').then(r => r.json()).then(c => {
    document.getElementById('provider').value = c.api_provider || 'none';
    document.getElementById('apiKey').value = '';
    document.getElementById('apiModel').value = c.api_model || '';
    document.getElementById('baseUrl').value = c.api_provider === 'local' ? (c.local_llm_url || '') : (c.api_base_url || '');
    document.getElementById('allowShell').checked = !!c.allow_shell;
  });
}

function saveSettings() {
  const provider = document.getElementById('provider').value;
  const body = {
    api_enabled: provider !== 'none',
    api_provider: provider,
    api_model: document.getElementById('apiModel').value,
    allow_shell: document.getElementById('allowShell').checked,
  };
  const key = document.getElementById('apiKey').value;
  if (key) body.api_key = key;
  const url = document.getElementById('baseUrl').value;
  if (provider === 'local') body.local_llm_url = url; else body.api_base_url = url;

  fetch('/api/config', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)})
    .then(() => alert('Saved.'));
}
</script>
</body>
</html>
"""


def create_app(engine):
    app = Flask(__name__)
    app.config["SECRET_KEY"] = SECRET_KEY
    socketio.init_app(app)

    @app.route("/")
    def index():
        return render_template_string(PAGE)

    @app.route("/api/status")
    def status():
        return jsonify(engine.status())

    @app.route("/api/chat", methods=["POST"])
    def chat():
        data = request.get_json(force=True, silent=True) or {}
        text = (data.get("text") or "").strip()
        if not text:
            return jsonify({"error": "empty message"}), 400
        response = engine.process(text)
        return jsonify({"response": response})

    @app.route("/api/config", methods=["GET"])
    def config_get():
        cfg = get_config()
        cfg["api_key"] = "•" * 8 if cfg.get("api_key") else ""
        return jsonify(cfg)

    @app.route("/api/config", methods=["POST"])
    def config_set():
        data = request.get_json(force=True, silent=True) or {}
        cfg = get_config()
        cfg.update({k: v for k, v in data.items() if v != ""})
        save_config(cfg)
        return jsonify({"saved": True})

    @socketio.on("user_message")
    def on_user_message(data):
        text = (data or {}).get("text", "").strip()
        if text:
            engine.process(text)  # response reaches clients via engine.emit("ai_response", ...)

    return app
