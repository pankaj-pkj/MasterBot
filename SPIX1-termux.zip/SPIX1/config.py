"""
SPIX1 — Global Configuration
Central configuration for the entire SPIX1 AI system.
Tuned for running under Termux on Android.
"""

import os
import secrets

# ─── Project Paths ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
WEB_DIR = os.path.join(BASE_DIR, "web")

# Shared Android storage (populated after running `termux-setup-storage`).
# File-manager operations use this when available so "create/delete/edit"
# requests reach real phone storage (Downloads, Documents, etc.), not just
# SPIX1's private sandbox. Falls back to a local folder if not set up yet.
_shared = os.path.expanduser("~/storage/shared")
FILES_BASE_DIR = _shared if os.path.isdir(_shared) else os.path.join(DATA_DIR, "files")

# ─── Data Files ────────────────────────────────────────────────
KNOWLEDGE_FILE = os.path.join(DATA_DIR, "knowledge.json")
MEMORY_FILE = os.path.join(DATA_DIR, "memory.json")
USER_CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
LOG_FILE = os.path.join(DATA_DIR, "spix1.log")
ALARM_LOG_FILE = os.path.join(DATA_DIR, "alarms.json")
SHELL_AUDIT_LOG = os.path.join(DATA_DIR, "shell_audit.log")

# ─── Web Dashboard ─────────────────────────────────────────────
# Bound to localhost by default — a phone is frequently on shared/public
# Wi-Fi, and this dashboard can trigger real device actions, so it should
# not be reachable from other devices on the network unless you choose
# that deliberately (see README).
HOST = "127.0.0.1"
PORT = 5050
DEBUG = False
# Generated once and persisted, instead of a fixed value shipped in source.
_secret_file = os.path.join(DATA_DIR, ".secret_key")
def _load_or_create_secret():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        if os.path.exists(_secret_file):
            with open(_secret_file, "r") as f:
                val = f.read().strip()
                if val:
                    return val
        val = secrets.token_hex(32)
        with open(_secret_file, "w") as f:
            f.write(val)
        return val
    except Exception:
        return secrets.token_hex(32)
SECRET_KEY = _load_or_create_secret()

# ─── AI Core ───────────────────────────────────────────────────
AI_NAME = "SPIX1"
AI_VERSION = "1.1.0-mobile"
AI_PERSONALITY = "helpful"  # helpful, formal, casual, witty
LEARNING_ENABLED = True
MAX_MEMORY_ENTRIES = 10000
CONFIDENCE_THRESHOLD = 0.55

# ─── Voice (via Termux:API — needs the Termux:API app installed) ──
VOICE_ENABLED = True

# ─── Self-Learning ─────────────────────────────────────────────
LEARNING_RATE = 0.15
FORGETTING_FACTOR = 0.97   # decay for unused knowledge
MAX_KNOWLEDGE_ENTRIES = 50000

# ─── System / Shell Access ─────────────────────────────────────
# Off by default. Termux already gives you a full shell natively —
# this just lets SPIX1 run commands *you* ask it to run, through chat.
# Turn on deliberately in data/config.json ("allow_shell": true) if you
# want that. Every command that runs this way is appended to
# SHELL_AUDIT_LOG so there's always a record of what SPIX1 executed.
ALLOW_SHELL_COMMANDS_DEFAULT = False
PROCESS_MONITOR_INTERVAL = 5  # seconds
MAX_LOG_SIZE_MB = 10

# ─── Reasoning backend (optional) ───────────────────────────────
# SPIX1's built-in NLP + learned-knowledge store works fully offline with
# no API of any kind — that's the default. This section lets you *add*
# a stronger reasoning layer on top, used only when the built-in matcher
# isn't confident it has a good answer:
#   provider = "none"      -> pure offline rule-based matching (default)
#   provider = "local"     -> a small GGUF model you run yourself via
#                             llama.cpp's `llama-server` on-device
#                             (see setup_termux.sh) — still no internet,
#                             still no API key
#   provider = "anthropic" -> Claude API, your own key
#   provider = "openai"    -> OpenAI-compatible API, your own key
#   provider = "custom"    -> any OpenAI-chat-compatible endpoint/base_url
API_ENABLED = False
DEFAULT_API_PROVIDER = "none"
LOCAL_LLM_URL = "http://127.0.0.1:8080"   # llama.cpp `llama-server` default
API_TIMEOUT = 30

# ─── Colors (CLI) ─────────────────────────────────────────────
class Colors:
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    MAGENTA = "\033[95m"
    RESET = "\033[0m"
    BOLD = "\033[1m"

# ─── Boot Banner ───────────────────────────────────────────────
BANNER = r"""
  ███████ ██ ██   ██  ██████  ██   ██
  ██      ██  ██ ██  ██    ██ ██   ██
  ███████ ██   ███   ██    ██ ███████
       ██ ██  ██ ██  ██    ██ ██   ██
  ███████ ██ ██   ██  ██████  ██   ██
              Self-Learning Assistant v{ver} — Termux Edition
""".format(ver=AI_VERSION)


def ensure_directories():
    """Create all required directories if they don't exist."""
    for directory in [DATA_DIR, os.path.join(DATA_DIR, "files")]:
        os.makedirs(directory, exist_ok=True)


def get_config():
    """Load user configuration, merging with defaults."""
    import json
    defaults = {
        "ai_name": AI_NAME,
        "personality": AI_PERSONALITY,
        "voice_enabled": VOICE_ENABLED,
        "learning_enabled": LEARNING_ENABLED,
        "allow_shell": ALLOW_SHELL_COMMANDS_DEFAULT,
        "api_enabled": API_ENABLED,
        "api_provider": DEFAULT_API_PROVIDER,
        "api_key": "",
        "api_model": "",
        "api_base_url": "",
        "local_llm_url": LOCAL_LLM_URL,
    }
    if os.path.exists(USER_CONFIG_FILE):
        try:
            with open(USER_CONFIG_FILE, "r") as f:
                user_cfg = json.load(f)
            defaults.update(user_cfg)
        except Exception:
            pass
    return defaults


def save_config(cfg):
    import json
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(USER_CONFIG_FILE, "w") as f:
            json.dump(cfg, f, indent=2)
        return True
    except Exception:
        return False
